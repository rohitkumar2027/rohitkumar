<?php
$db=mysqli_connect("localhost","root","","my_portfolio");
//if($db){
//    echo "databse is connected !";
//}else{
//    echo "something is wrong with database !";
//}